香港中国银行(BOC)对接     ZA_LIFE银行转账方式的退款通过和BOC的报回盘文件方式进行交互，
主要流程如下     
1.ZA_LIFE每天16:30统计截止到当前时间为止的银行退款交易，通过PGP的加密加签的方式生成MutiTrans文件，随后上传到BOC的SFTP文件服务器上     
2. BOC在MutiTrans文件上传后，15min内生成Acknowledgement File(ACK)并放在服务器上，ZA_LIFE每天17:00从服务器上解析文件     
3. ZA_LIFE每天09:00从文件服务器上获取Daily Report File(T001)，确认交易是否正常处理     
4. ZA_LIFE每天18:00从文件服务器上获取Trans Report File(A005)，确认交易的最终结果

业务对接人:     Daniel(daniel.lin@za.group)     Billy(billy_tsui@bochk.com) 
运维：     李奕(yi.li@za.group)          

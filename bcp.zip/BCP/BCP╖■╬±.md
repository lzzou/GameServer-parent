#  **BCP**

[TOC]

--------------------------

## 1\.  先产生实收数据，然后产生应收账单
### NB/Reinstatement

>> ① /operate/fee/processCollection

>> ② /operate/fee/updateBill

>> ③ async consume policy effective/change kfaka msg

----------------------

## 2\. 提前抽取账单，后缴费，最后核销
### Renew/Renewal Policy

>> ① /operate/fee/processReceivable

>> ② /operate/fee/processCollection

>> ③ /operate/fee/updateBill 

>> ④ /operate/fee/updateBill 

---------------------------

## 3\.  收款后，check failed，后退款
### Reject Refund/Reinstatement Refund

>> ① /operate/fee/processCollection

>> ② /operate/fee/updateBill 

>> ③ /operate/fee/processPayment

>> ④ /operate/fee/updateBill 

---------------------------

## 4\.  保费、账户余额、理赔退款流程
### Cooling off/Rescind Policy/Claim

>> ① /operate/fee/processPayment

>> ② /operate/fee/updateBill 

---------------------------

## 5\. 准备金
### Claim Provision

>> ① /operate/fee/processPayment  Claim Provision

>> ② /operate/fee/processPayment  Claim Provision Reverse

---------------------------

## 6\. 保费变更
###  Decrease Sum Assured
>>  ① /operate/fee/updateBill 

###  ~~Customer Smoking Change~~
>> consume policy change kafka msg 

---------------------------

## 7\. 保单失效、终止,对账单影响

> consume policy change kafka msg

### Renew Expire/Renewal Policy Expire
>> policy status is TERMINATION, update unpaid bill to cancel


### Cooling off/Rescind Policy/Claim
>> policy status is TERMINATION, cancel has paid, but not confirm bill

---------------------------

## 8\. 特殊收款场景
### Rescind Policy
>> 理赔金追回金额大于解约退款保费金额

---------------------------

## 9\. 通知
### 催缴通知
### 账单未缴失效通知

---------------------------

## 10\. 第三方服务

### Bank Auto Pay(BOC)
>> 香港中国银行(BOC)对接
    ZA_LIFE银行转账方式的退款通过和BOC的报回盘文件方式进行交互，主要流程如下:

    1.ZA_LIFE每天16:30统计截止到当前时间为止的银行退款交易，通过PGP的加密加签的方式生成MutiTrans文件，随后上传到BOC的SFTP文件服务器上

    2. BOC在MutiTrans文件上传后，15min内生成Acknowledgement File(ACK)并放在服务器上，ZA_LIFE每天17:00从服务器上解析文件

    3. ZA_LIFE每天09:00从文件服务器上获取Daily Report File(T001)，确认交易是否正常处理

    4. ZA_LIFE每天18:00从文件服务器上获取Trans Report File(A005)，确认交易的最终结果
    
    
## 11\. 接口示例

### /operate/fee/processCollection
> 收费





### /operate/fee/processReceivable  

> 创建续期账单示例  

```json
{
    "arAp":"Ar",
    "businessTransactionNo":"CMH021319872",
    "channel":"DM_PC",
    "frequency":2,
    "payFrequencyType":"MONTH",
    "payeeId":182191,
    "policyNo":"ZAJ021917056",
    "transAmount":"155.58",
    "transType":"RENEWAL",
    "arApDetailList":[
        {
            "accountNo":"",
            "channel":"DM_PC",
            "currency":"HKD",
            "discountedExtraPremium":"0.00",
            "discountedPremium":"155.42",
            "dueDate":2241705600000,
            "extraPremium":"0.00",
            "feeAmount":"155.42",
            "feePurpose":"PREMIUM",
            "feeType":"INSURANCE_PREMIUM",
            "nextDueDate":2244384000000,
            "payMethod":"STRIPE",
            "payeeId":182191,
            "policyProductId":138003,
            "productCode":"Eheart",
            "productId":454063
        },
        {
            "accountNo":"",
            "currency":"HKD",
            "discountedPremium":"0.16",
            "dueDate":2241705600000,
            "feeAmount":"0.16",
            "feePurpose":"LEVY",
            "feeType":"POLICY_LEVY",
            "payMethod":"STRIPE",
            "payeeId":182191
        }
    ]
}

```


### /operate/fee/processCollection

> 新单收款示例

```json
{
    "businessTransactionNo":"NOP021411456",
    "channel":"DM_PC",
    "transAmount":"724.62",
    "transType":"EFECTIVE_POLICY",
    "colDetailList":[
        {
            "accountNo":"7552",
            "currency":"HKD",
            "feeAmount":"0.10",
            "feePurpose":"PREMIUM",
            "feeType":"POLICY_TEMPORARILY",
            "payMethod":"STRIPE",
            "payeeId":157492,
            "productId":456003
        },
        {
            "accountNo":"7552",
            "currency":"HKD",
            "feeAmount":"0.00",
            "feePurpose":"LEVY",
            "feeType":"POLICY_TEMPORARILY",
            "payMethod":"STRIPE",
            "payeeId":157492,
            "productId":456003
        },
        {
            "accountNo":"7552",
            "currency":"HKD",
            "feeAmount":"723.90",
            "feePurpose":"PREMIUM",
            "feeType":"POLICY_TEMPORARILY",
            "payMethod":"COUPON_DEDUCTIBLE",
            "payeeId":157492,
            "productId":456003
        },
        {
            "accountNo":"7552",
            "currency":"HKD",
            "feeAmount":"0.62",
            "feePurpose":"LEVY",
            "feeType":"POLICY_TEMPORARILY",
            "payMethod":"COUPON_DEDUCTIBLE",
            "payeeId":157492,
            "productId":456003
        }
    ]
}
```


### /operate/fee/processPayment

> 拒保退费参数示例  

```json
{
    "businessTransactionNo":"NOY021722752",
    "transAmount":"187.16",
    "transType":"REJECT_REFUND",
    "channel":"ZA_BANK",
    "payDetailList":[
        {
            "accountNo":"6203",
            "currency":"HKD",
            "feeAmount":"187.00",
            "feePurpose":"PREMIUM",
            "feeType":"REAL_REFUND_FEE",
            "payMethod":"STRIPE",
            "payeeId":121320,
            "productId":456003
        },
        {
            "accountNo":"6203",
            "currency":"HKD",
            "feeAmount":"0.16",
            "feePurpose":"LEVY",
            "feeType":"REAL_REFUND_FEE",
            "payMethod":"STRIPE",
            "payeeId":121320,
            "productId":456003
        },
        {
            "accountNo":"6203",
            "currency":"HKD",
            "feeAmount":"46.75",
            "feePurpose":"PREMIUM",
            "feeType":"REAL_REFUND_FEE",
            "payMethod":"COUPON_DEDUCTIBLE",
            "payeeId":121320,
            "productId":456003
        },
        {
            "accountNo":"6203",
            "currency":"HKD",
            "feeAmount":"0.04",
            "feePurpose":"LEVY",
            "feeType":"REAL_REFUND_FEE",
            "payMethod":"COUPON_DEDUCTIBLE",
            "payeeId":121320,
            "productId":456003
        }
    ]
}
```

> 准备金参数示例

``` json
{
    "businessTransactionNo":"ICU021341248",
    "transType":"CLAIM",
    "payDetailList":[
        {
            "currency":"HKD",
            "feeAmount":"300.0",
            "feeType":"RESERVE",
            "policyNo":"ZAB020101888",
            "policyProductId":"216011",
            "productCode":"PA3",
            "productId":499003
        }
    ]
}
```

> 犹豫期退保参数示例

``` json
{
    "businessTransactionNo":"PAF021834304",
    "channel":"ZA_BANK",
    "transAmount":"0.30",
    "transType":"FREELOOKSURRENDER",
    "payDetailList":[
        {
            "arAp":"Ap",
            "channel":"ZA_BANK",
            "currency":"HKD",
            "discountedPremium":"0.30",
            "dueDate":1616083200000,
            "feeAmount":"0.50",
            "feePurpose":"CANCEL_FROM_INCEPTION",
            "feeType":"COOLING_OFF_REFUND",
            "payMethod":"ZA_BANK",
            "payeeId":137026,
            "policyNo":"ZAU021215680",
            "policyProductId":"133026",
            "productCode":"Eheart",
            "productId":454063
        },
        {
            "arAp":"Ap",
            "channel":"ZA_BANK",
            "currency":"HKD",
            "discountedPremium":"0.00",
            "dueDate":1616083200000,
            "feeAmount":"0.00",
            "feePurpose":"LEVY_CANCEL_FROM_INCEPTION",
            "feeType":"POLICY_LEVY_REFUND",
            "payMethod":"ZA_BANK",
            "payeeId":137026,
            "policyNo":"ZAU021215680"
        },
        {
            "arAp":"Ap",
            "channel":"ZA_BANK",
            "currency":"HKD",
            "discountedPremium":"0.30",
            "dueDate":1616083200000,
            "feeAmount":"0.30",
            "feePurpose":"COMMISSION_CANCEL_FROM_INCEPTION",
            "feeType":"COMMISSION_REFUND",
            "payMethod":"ZA_BANK",
            "payeeId":137026,
            "policyNo":"ZAU021215680"
        },
        {
            "arAp":"Ap",
            "channel":"ZA_BANK",
            "currency":"HKD",
            "discountedPremium":"0.30",
            "dueDate":1617157725000,
            "feeAmount":"0.30",
            "feePurpose":"CANCEL_FROM_INCEPTION",
            "feeType":"REAL_REFUND_FEE",
            "payMethod":"ZA_BANK",
            "payeeId":137026,
            "policyNo":"ZAU021215680",
            "policyProductId":"133026",
            "productCode":"Eheart",
            "productId":454063
        },
        {
            "arAp":"Ap",
            "channel":"ZA_BANK",
            "currency":"HKD",
            "discountedPremium":"0.20",
            "dueDate":1616083200000,
            "feeAmount":"0.20",
            "feePurpose":"CANCEL_FROM_INCEPTION",
            "feeType":"REAL_REFUND_FEE",
            "payMethod":"COUPON_DEDUCTIBLE",
            "payeeId":137026,
            "policyNo":"ZAU021215680",
            "policyProductId":"133026",
            "productCode":"Eheart",
            "productId":454063
        }
    ]
}

```

--------------------------------------------

### /operate/fee/updateBill

> 新单支付成功参数示例

```json
{
    "bizApplyNo":"1063075",
    "businessTransactionNo":"NOO021866752",
    "canWithhold":"YES",
    "payeeId":180059,
    "tradeStatus":"SUCCEEDED",
    "transType":"EFECTIVE_POLICY"
}

```

> 续期核销参数示例

```json
{
    "businessTransactionNo":"CMQ021737216",
    "payeeId":133123,
    "tradeStatus":"SUCCEEDED"
}

```



    
    
    

# **BCP BACKEND**
[TOC]
## 退款记录查询
> /bcp-backend/queryPayment   
相关退款记录查询，如Payment Enquiry，Bank Autopay Authorization界面
-----------------------------------

## 财务审批
> /bcp-backend/financialApproval  
银行转账方式退款，需要财务人员进行审批，审批通过后，才能退款

-----------------------------------

## 解冻WC pending记录 
> /bcp-backend/paymentApprove  
犹退解约时，需要对领款人进行World Check，Check pending后，会进入Compliance进行审批，审批通过后，调用此方法接触pending状态，变为待支付或者待审批， 或者直接发起退款

-----------------------------------

## 查询BOC交易纪录
> /bcp-backend/queryTransFile  

-----------------------------------

## 查询BOC交易纪录明细
> /bcp-backend/queryBeneficiaryDetail

----------------------------------

## 查询失败交易纪录
> /bcp-backend/queryFailHistory

## 支票管理
> 支票列表查询， 支票签发， 支票兑现，支票取消， 查询操作历史等功能